# syndesiCLI
Syndesi command line interface
