class Payload():
    def __init__(self):
        """
        Payload base class
        """
        self._reply = None
        pass
    def value():
        pass
    def parse():
        pass