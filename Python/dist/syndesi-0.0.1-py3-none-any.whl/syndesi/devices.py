# Devices utilities
#
# Sébastien Deriaz
# 14.11.2022
from .device import Device

def list_devices():
    """
    List devices
    """