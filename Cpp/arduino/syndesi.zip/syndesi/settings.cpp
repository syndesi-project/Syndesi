/**
 * @file settings.cpp
 *
 * @brief Syndesi settings
 *
 * @author Sébastien Deriaz
 * @date 02.11.2022
 */

#include "settings.h"

namespace syndesi {

Settings settings;

}
