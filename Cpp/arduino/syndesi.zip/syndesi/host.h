/**
 * @file host.h
 *
 * @brief Host specific commands
 *
 * @author Sébastien Deriaz
 * @date 03.11.2022
 */